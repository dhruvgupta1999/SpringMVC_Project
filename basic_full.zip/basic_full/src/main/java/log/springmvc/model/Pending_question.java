package log.springmvc.model;

public class Pending_question {
	
    int Q_id;
    String Question;
    
	public int getQ_id() {
		return Q_id;
	}

	public void setQ_id(int q_id) {
		Q_id = q_id;
	}

	public String getQuestion() {
		return Question;
	}

	public void setQuestion(String question) {
		Question = question;
	}
	

}
