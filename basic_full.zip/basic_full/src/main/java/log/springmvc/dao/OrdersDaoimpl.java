package log.springmvc.dao;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import log.springmvc.model.Cart;
import log.springmvc.model.Cartdisplay;
//import log.springmvc.model.Cart;
import log.springmvc.model.Customer;
import log.springmvc.model.Orderdisplay;
import log.springmvc.model.Orders;
//import log.springmvc.model.Orders;

public class OrdersDaoimpl implements OrdersDao{
	@Autowired
	  DataSource datasource;
	  @Autowired
	  JdbcTemplate jdbcTemplate;
	  public List<Orderdisplay> showOrders(String user) {
	    String sql = "select * from Orders,Product where Username='" + user + "' and Orders.P_id = Product.P_id";
	    return jdbcTemplate.query(sql, new OrdersMapper());
     }
	  
	 public void addCarttoOrders(String user) // automatically removes from cart as well
	 {
		 String sql1 = "select * from Cart where Username='" + user + "'";
		 List<Cart> cart_items =  jdbcTemplate.query(sql1, new CartMapper());
		 String sql2 = "delete from Cart where Username='" + user + "'";
		 jdbcTemplate.update(sql2);
		 for (Cart temp : cart_items) {
			 System.out.println("added an order");
			 String sql = "insert into Orders values(?,?,?)";
			  jdbcTemplate.update(sql, new Object[] { temp.getUsername(), temp.getP_id(), temp.getQty() });
			}	  
	 }
}

class OrdersMapper implements RowMapper<Orderdisplay> {
    public Orderdisplay mapRow(ResultSet rs, int arg1) throws SQLException {
    Orderdisplay cart = new Orderdisplay();
    cart.setUsername(rs.getString("Username"));
    cart.setP_id(rs.getString("P_id"));
    cart.setCompany(rs.getString("Company"));
    cart.setPrice(rs.getDouble("Price"));
    cart.setType(rs.getString("Type"));
    cart.setSize(rs.getString("Size"));
    cart.setTprice(rs.getDouble("Price")*rs.getInt("Qty"));
    cart.setQty(rs.getInt("Qty"));
    
    return cart;
  }
}
