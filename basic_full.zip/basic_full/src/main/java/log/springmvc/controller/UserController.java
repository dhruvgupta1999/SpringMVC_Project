package log.springmvc.controller;

import java.security.Principal;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.AuthorityUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import log.springmvc.dao.AccountDao;
import log.springmvc.dao.Answered_questionDao;
import log.springmvc.dao.CartDao;
import log.springmvc.dao.CustomerDao;
import log.springmvc.dao.OrdersDao;
import log.springmvc.dao.Pending_QuestionDao;
import log.springmvc.dao.ProductDao;
import log.springmvc.model.Accounts;
import log.springmvc.model.Answered_question;
import log.springmvc.model.Cart;
import log.springmvc.model.Cartdisplay;
import log.springmvc.model.Customer;
import log.springmvc.model.Employee;
import log.springmvc.model.Product;
import log.springmvc.model.Productform;
import log.springmvc.model.Stringholder;

@Controller
public class UserController {
	@Autowired
	public AccountDao accdao;
	
	@Autowired
	CartDao cartdao;
	
	@Autowired
	OrdersDao ordersdao;
	
	@Autowired
	Pending_QuestionDao pq;
	
	@Autowired
	Answered_questionDao aq;
	
	@Autowired
	public CustomerDao custdao;
	
	@Autowired
	ProductDao prod_dao;
	
	
	public Accounts acc;
	
	
	public Employee emp;
	
	Model model;
	
//	@RequestMapping(value = "dashboard", method = RequestMethod.GET)
//	public String dashview(Principal principal, Authentication authentication)
//	{
//	String logged_user = principal.getName();
//	model.addAttribute("user",logged_user);
//	Set<String> authority = AuthorityUtils.authorityListToSet(authentication.getAuthorities());
//	if (authority.contains("ROLE_ADMIN")) {
//		return "/admin";
//	}
//	else if(authority.contains("ROLE_EMP"))
//	{
//		return "/emp";
//	}
//	
//	return "/user";
//	
//	}
	
	@RequestMapping(value = "user/cart")
	public ModelAndView displaycart(Principal principal, Authentication authentication)
	{
		System.out.println("reached displaycart()");
		String logged_user = principal.getName();
		ModelAndView mv = new ModelAndView();
		List<Cartdisplay> l = cartdao.showCart(logged_user);
//		System.out.println(l.get(0).getCompany());
		mv.addObject("cartlist",l);
		mv.setViewName("cart");
		return mv;
	}
	
	@RequestMapping(value = "user/orders")
	public ModelAndView displayorders(Principal principal, Authentication authentication)
	{
		System.out.println("reached displayorders()");
		String logged_user = principal.getName();
		ModelAndView mv = new ModelAndView();
		mv.addObject("orderlist",ordersdao.showOrders(logged_user));
		mv.setViewName("orders");
		return mv;
	}
	
	@RequestMapping(value = "user/delcart/{C_id}")
	public String removeitemfromcart(@PathVariable(value="C_id") int C_id,Principal principal )
	{
		System.out.println("reached delfromcart()");
		cartdao.removefromCart(principal.getName(), C_id);
//		return "redirect:user/cart";
		return "redirect:/user/cart";
	}
	
	@RequestMapping(value = "user/buy")
	public String purchaseitems(Principal principal)
	{
		String username = principal.getName();
	    ordersdao.addCarttoOrders(username);
	    return "redirect:/user/orders";
	}
	
	@RequestMapping(value = {"user/faq","emp/faq"})
	public ModelAndView faqfn (Principal principal) {
		ModelAndView mv=new ModelAndView();
//		mv.addObject("user_name",principal.getName());
		mv.addObject("user_role", accdao.getUserRole(principal.getName()));
		mv.addObject("pending_questions",pq.showPending_questions());
		mv.addObject("answered_questions",aq.showAns());
		mv.setViewName("faq"); 
		return mv;
		
	}
	
	@RequestMapping(value="/user/productform",method=RequestMethod.GET)
	public String productform(Model model) {
		System.out.println("reached productformfn()");
		model.addAttribute("product",new Productform());
		return "Newaddproductform";
	}	
	
	@RequestMapping(value = "/user/getproduct") //shows price,net price and availability 
	public ModelAndView addproduct(@ModelAttribute(value = "product") Productform product)
	{
		String type = product.getType();
		String size = product.getSize();
		String company = product.getCompany();
		int qty = product.getQuantity();
		Product pr = prod_dao.getProd(type, size, company);
		double price = pr.getPrice();
		price = Math.round(price*100)/100.0;
		double tprice = Math.round(price*100*qty)/100.0;
		ModelAndView mv  = new ModelAndView();
		if(qty>0)
		{
		
		mv.addObject("pid",pr.getP_id());
		mv.addObject("price",price);
		mv.addObject("tprice",tprice);
		mv.addObject("type",type);
		mv.addObject("company",company);
		mv.addObject("size",size);
		mv.addObject("qty",qty);
		
		}
		else
		{
			mv.addObject("error_message","please enter a valid quantity!");
		}
		mv.setViewName("addproduct");
		return mv;
		
	}
	
	@RequestMapping(value = "/user/addtocart" ,method=RequestMethod.GET)
	public String addtocart(Principal principal,@RequestParam("pid") String pid, @RequestParam("qty") int qty ){
		Cart cart = new Cart();
		cart.setP_id(pid);
		cart.setQty(qty);
		cart.setUsername(principal.getName());
		cartdao.addtoCart(cart);
		return "redirect:/user/productform";
	}
	
	@RequestMapping(value = "/user/ask_q", method = RequestMethod.GET)
	public String askq(Model model) {
		System.out.println("reached askqfn()");
		model.addAttribute("myquestion",new Stringholder());
		return "askqform";
	}
	
	
	
	@RequestMapping(value = "/user/add_q/", method = RequestMethod.POST)
	public ModelAndView addq(@ModelAttribute(value = "myquestion") Stringholder question ,BindingResult result) {
		System.out.println("reached addq()");
		pq.addPending_question(question.getQuestion());
		ModelAndView mv = new ModelAndView();
		mv.addObject("q_done","true");
		mv.setViewName("askqform");
		return mv;
	}
	
}
	
	

