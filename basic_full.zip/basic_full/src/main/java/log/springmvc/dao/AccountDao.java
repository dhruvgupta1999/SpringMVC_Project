package log.springmvc.dao;

import log.springmvc.model.Accounts;
import log.springmvc.model.Customer;
import log.springmvc.model.Employee;
//import log.springmvc.model
public interface AccountDao {
    void registerAcc(Accounts account);
    Customer validateCustomer(Accounts account);
    Employee validateEmployee(Accounts account);
    public String getUserRole(String user);
}
