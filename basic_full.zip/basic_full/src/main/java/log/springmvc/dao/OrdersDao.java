package log.springmvc.dao;

import java.util.List;

//import log.springmvc.model.Cart;
import log.springmvc.model.Customer;
import log.springmvc.model.Orderdisplay;
import log.springmvc.model.Orders;

public interface OrdersDao {
    List<Orderdisplay> showOrders(String user);
    public void addCarttoOrders(String user);
}
