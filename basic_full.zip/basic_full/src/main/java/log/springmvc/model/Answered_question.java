package log.springmvc.model;

public class Answered_question {
   String Question;
   String Answer;
public String getQuestion() {
	return Question;
}
public void setQuestion(String question) {
	Question = question;
}
public String getAnswer() {
	return Answer;
}
public void setAnswer(String answer) {
	Answer = answer;
}
   
}
