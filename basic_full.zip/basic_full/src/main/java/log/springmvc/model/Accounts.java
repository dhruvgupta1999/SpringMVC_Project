package log.springmvc.model;

public class Accounts {
	String Username; 
	String Password ;
    String UserRole ;
//    int Enabled;
    
//	public int getEnabled() {
//		return Enabled;
//	}
//	public void setEnabled(int enabled) {
//		this.Enabled = enabled;
//	}
	public String getUsername() {
		return Username;
	}
	public void setUsername(String username) {
		Username = username;
	}
	public String getPassword() {
		return Password;
	}
	public void setPassword(String password) {
		Password = password;
	}
	public String getUserRole() {
		return UserRole;
	}
	public void setUserRole(String userRole) {
		UserRole = userRole;
	}
	
    
}
