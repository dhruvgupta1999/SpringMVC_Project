package log.springmvc.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import log.springmvc.dao.AccountDao;
import log.springmvc.dao.Answered_questionDao;
import log.springmvc.dao.CartDao;
import log.springmvc.dao.CustomerDao;
import log.springmvc.dao.OrdersDao;
import log.springmvc.dao.Pending_QuestionDao;
import log.springmvc.dao.ProductDao;
import log.springmvc.model.Accounts;
import log.springmvc.model.Answered_question;
import log.springmvc.model.Employee;

@Controller
public class EmpController {
	@Autowired
	public AccountDao accdao;
	
	@Autowired
	CartDao cartdao;
	
	@Autowired
	OrdersDao ordersdao;
	
	@Autowired
	Pending_QuestionDao pq;
	
	@Autowired
	Answered_questionDao aq;
	
	@Autowired
	public CustomerDao custdao;
	
	@Autowired
	ProductDao prod_dao;
	
	
	public Accounts acc;
	
	
	public Employee emp;
	
	Model model;
	
	@RequestMapping(value = "/emp/ans_q/{Q_id}")
	public String answercreatefn(@PathVariable(value="Q_id") int Q_id,@RequestParam("Answer") String answer) {
		String question = pq.q_details(Q_id).getQuestion();
		pq.delPending_question(Q_id);
		Answered_question obj = new Answered_question();
		obj.setQuestion(question);
		obj.setAnswer(answer);
		aq.addAns(obj);
		return "redirect:/emp/faq";
		
	}
	@RequestMapping(value = "/emp/del_q/{Q_id}")
	public String delpendingfn(@PathVariable(value="Q_id") int Q_id) {
		pq.delPending_question(Q_id);
		return "redirect:/emp/faq";
		
	}
}
