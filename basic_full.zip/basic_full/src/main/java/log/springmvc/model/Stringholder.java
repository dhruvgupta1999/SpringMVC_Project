package log.springmvc.model;

public class Stringholder {
    String question;

	public String getQuestion() {
		return question;
	}

	public void setQuestion(String question) {
		this.question = question;
	}

	
    
}
