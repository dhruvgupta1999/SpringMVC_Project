package log.springmvc.dao;

import log.springmvc.model.Accounts;
import log.springmvc.model.Customer;

public interface CustomerDao {
    void registerCustomer(Customer customer);
    
}
