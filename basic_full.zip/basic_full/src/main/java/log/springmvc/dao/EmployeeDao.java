package log.springmvc.dao;

import log.springmvc.model.Employee;
import java.util.List;

public interface EmployeeDao {
    List<Employee> showEmployee();
}
